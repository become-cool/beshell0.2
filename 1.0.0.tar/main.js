
const model = require('./model.js')
model.setup()
model.runCards()
