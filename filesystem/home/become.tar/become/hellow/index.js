const app = require("./app.js")
global.app = app

app.setup()

app.main()
