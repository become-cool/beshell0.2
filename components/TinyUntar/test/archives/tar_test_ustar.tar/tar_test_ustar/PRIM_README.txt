This archive was created by TAR under Linux, which uses the USTAR-TAR format. It also shows how this format can describe device files and links.
