This archive was created by 7-Zip under Windows, which uses the old TAR format (non-ustar).
