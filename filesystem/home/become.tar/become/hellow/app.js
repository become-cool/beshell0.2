lv = require("lv")

// 该文件由 Workspace 自动生成，所有修改都可能在下次保存时被还原
module.exports = {
    var: {}, part: {}, ui: {} ,

    setup () {
        let screen = new lv.CleanObj()
        screen.fromJson(JSON.load(__dirname+"/ui.json"), this.ui)
        lv.loadScreen(screen)


    } ,
    
    main () {
        app.ui["btn0"].on("clicked",()=>{
            if(isNaN(this.ui["btn0"].text())){
                this.ui["btn0"].setText(0)
            }
            this.ui["btn0"].setText(Number(this.ui["btn0"].text()) + Number(1))
        })



    } ,
}
